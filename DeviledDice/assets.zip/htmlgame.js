(() => {
  // itch.io's hotlink check used to live here: it reported the referring
  // domain to itch.io's own analytics endpoint, and redirected the browser
  // away to itch.io whenever the page wasn't embedded from itch.io or
  // itch.zone. That made sense for an embed of someone else's itch.io
  // listing; it does not here, since PixelNebula is this game's real home,
  // not a hotlinked copy of one. Disabled rather than repurposed - there is
  // no one left to redirect away from.
  //
  // Also unused: Games/DeviledDice/index.html never loads this file, and it
  // is deliberately left out of assets.zip.
})();
