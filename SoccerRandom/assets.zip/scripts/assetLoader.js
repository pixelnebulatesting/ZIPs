/**
 * Dynamic Asset Loader for ZIP-based games
 * This module handles loading assets from assets.zip and making them available to the game
 */

class AssetLoader {
    constructor() {
        this.zip = null;
        this.loadedAssets = new Map();
        this.assetUrls = new Map(); // Maps original paths to blob URLs
        this.isLoaded = false;
        this.loadingPromise = null;
    }

    /**
     * Initialize the asset loader by fetching and extracting the zip file
     * @param {string} zipPath - Path to the assets.zip file
     * @returns {Promise<void>}
     */
    async init(zipPath = 'assets.zip') {
        if (this.loadingPromise) {
            return this.loadingPromise;
        }

        this.loadingPromise = this._loadZip(zipPath);
        return this.loadingPromise;
    }

    /**
     * Private method to load and extract the zip file
     * @param {string} zipPath - Path to the zip file
     * @returns {Promise<void>}
     */
    async _loadZip(zipPath) {
        try {
            console.log('[AssetLoader] Fetching assets.zip...');
            
            // Fetch the zip file
            const response = await fetch(zipPath);
            if (!response.ok) {
                throw new Error(`Failed to fetch ${zipPath}: ${response.status} ${response.statusText}`);
            }

            const zipArrayBuffer = await response.arrayBuffer();
            
            console.log('[AssetLoader] Loading zip file with JSZip...');
            
            // Load the zip file with JSZip
            this.zip = await JSZip.loadAsync(zipArrayBuffer);
            
            console.log('[AssetLoader] Extracting assets from zip...');
            
            // Extract all files and create blob URLs
            await this._extractAssets();
            
            this.isLoaded = true;
            console.log(`[AssetLoader] Successfully loaded ${this.loadedAssets.size} assets from zip`);
            
        } catch (error) {
            console.error('[AssetLoader] Error loading assets:', error);
            throw error;
        }
    }

    /**
     * Extract all assets from the zip and create blob URLs
     * @returns {Promise<void>}
     */
    async _extractAssets() {
        const extractionPromises = [];

        this.zip.forEach((relativePath, zipEntry) => {
            // Skip directories
            if (zipEntry.dir) return;

            const extractionPromise = this._extractSingleAsset(relativePath, zipEntry);
            extractionPromises.push(extractionPromise);
        });

        await Promise.all(extractionPromises);
    }

    /**
     * Extract a single asset from the zip
     * @param {string} path - File path within the zip
     * @param {JSZip.JSZipObject} zipEntry - The zip entry object
     * @returns {Promise<void>}
     */
    async _extractSingleAsset(path, zipEntry) {
        try {
            // Determine the appropriate output format based on file type
            const mimeType = this._getMimeType(path);
            let blob;

            if (this._isTextFile(path)) {
                // For text files (CSS, JS, HTML, etc.)
                const content = await zipEntry.async('text');
                blob = new Blob([content], { type: mimeType });
            } else {
                // For binary files (images, audio, etc.)
                const arrayBuffer = await zipEntry.async('arraybuffer');
                blob = new Blob([arrayBuffer], { type: mimeType });
            }

            // Create blob URL
            const blobUrl = URL.createObjectURL(blob);
            
            // Store the asset
            this.loadedAssets.set(path, {
                blob: blob,
                url: blobUrl,
                mimeType: mimeType,
                size: blob.size
            });

            // Also store with normalized path (without leading slash)
            const normalizedPath = path.startsWith('/') ? path.substring(1) : path;
            if (normalizedPath !== path) {
                this.loadedAssets.set(normalizedPath, this.loadedAssets.get(path));
            }

        } catch (error) {
            console.warn(`[AssetLoader] Failed to extract ${path}:`, error);
        }
    }

    /**
     * Get the MIME type for a file based on its extension
     * @param {string} filename - The filename
     * @returns {string} - The MIME type
     */
    _getMimeType(filename) {
        const ext = filename.split('.').pop().toLowerCase();
        const mimeTypes = {
            // Images
            'png': 'image/png',
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'gif': 'image/gif',
            'svg': 'image/svg+xml',
            'webp': 'image/webp',
            
            // Audio
            'mp3': 'audio/mpeg',
            'wav': 'audio/wav',
            'ogg': 'audio/ogg',
            'webm': 'audio/webm',
            'm4a': 'audio/mp4',
            
            // Video
            'mp4': 'video/mp4',
            'webm': 'video/webm',
            
            // Text/Code
            'js': 'application/javascript',
            'json': 'application/json',
            'css': 'text/css',
            'html': 'text/html',
            'txt': 'text/plain',
            
            // Other
            'wasm': 'application/wasm'
        };

        return mimeTypes[ext] || 'application/octet-stream';
    }

    /**
     * Check if a file is a text file
     * @param {string} filename - The filename
     * @returns {boolean}
     */
    _isTextFile(filename) {
        const ext = filename.split('.').pop().toLowerCase();
        const textExtensions = ['js', 'json', 'css', 'html', 'txt', 'xml', 'svg'];
        return textExtensions.includes(ext);
    }

    /**
     * Get a blob URL for an asset
     * @param {string} path - The asset path
     * @returns {string|null} - The blob URL or null if not found
     */
    getAssetUrl(path) {
        // Normalize path
        const normalizedPath = path.startsWith('/') ? path.substring(1) : path;
        
        // Check both original and normalized paths
        const asset = this.loadedAssets.get(path) || this.loadedAssets.get(normalizedPath);
        return asset ? asset.url : null;
    }

    /**
     * Get an asset blob
     * @param {string} path - The asset path
     * @returns {Blob|null} - The blob or null if not found
     */
    getAssetBlob(path) {
        const normalizedPath = path.startsWith('/') ? path.substring(1) : path;
        const asset = this.loadedAssets.get(path) || this.loadedAssets.get(normalizedPath);
        return asset ? asset.blob : null;
    }

    /**
     * Get asset as data URL
     * @param {string} path - The asset path
     * @returns {Promise<string|null>} - The data URL or null if not found
     */
    async getAssetDataUrl(path) {
        const blob = this.getAssetBlob(path);
        if (!blob) return null;

        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }

    /**
     * Check if an asset exists
     * @param {string} path - The asset path
     * @returns {boolean}
     */
    hasAsset(path) {
        const normalizedPath = path.startsWith('/') ? path.substring(1) : path;
        return this.loadedAssets.has(path) || this.loadedAssets.has(normalizedPath);
    }

    /**
     * Get all loaded asset paths
     * @returns {string[]}
     */
    getAssetPaths() {
        return Array.from(this.loadedAssets.keys());
    }

    /**
     * Override URL handling to redirect to blob URLs
     * This method can be used to patch existing asset loading code
     */
    patchAssetLoading() {
        const originalFetch = window.fetch;
        const assetLoader = this;

        window.fetch = function(url, options) {
            // If this is a request for an asset we have in our zip
            if (typeof url === 'string' && assetLoader.hasAsset(url)) {
                const blobUrl = assetLoader.getAssetUrl(url);
                if (blobUrl) {
                    return originalFetch(blobUrl, options);
                }
            }
            
            return originalFetch(url, options);
        };

        console.log('[AssetLoader] Patched fetch() to use zip assets');
    }

    /**
     * Cleanup - revoke all blob URLs
     */
    cleanup() {
        for (const [path, asset] of this.loadedAssets) {
            URL.revokeObjectURL(asset.url);
        }
        this.loadedAssets.clear();
        this.isLoaded = false;
    }
}

// Create global instance
window.assetLoader = new AssetLoader();

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', async () => {
    try {
        await window.assetLoader.init();
        
        // Optional: Patch asset loading automatically
        window.assetLoader.patchAssetLoading();
        
        // Dispatch custom event when assets are ready
        window.dispatchEvent(new CustomEvent('assetsReady', {
            detail: { 
                assetCount: window.assetLoader.loadedAssets.size,
                assetPaths: window.assetLoader.getAssetPaths()
            }
        }));
        
    } catch (error) {
        console.error('[AssetLoader] Failed to initialize:', error);
        
        // Dispatch error event
        window.dispatchEvent(new CustomEvent('assetsError', {
            detail: { error }
        }));
    }
});