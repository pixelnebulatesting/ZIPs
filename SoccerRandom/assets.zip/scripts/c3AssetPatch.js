/**
 * Construct 3 Asset Loader Patch
 * This script patches Construct 3's asset loading to work with zip-based assets
 */

(function() {
    'use strict';
    
    console.log('[C3AssetPatch] Initializing Construct 3 asset loading patches...');
    
    // Store original functions that we'll patch
    const originalFetch = window.fetch;
    const originalXMLHttpRequest = window.XMLHttpRequest;
    const originalImage = window.Image;
    const originalAudio = window.Audio;
    
    // Track if patches are active
    let patchesActive = false;
    
    /**
     * Patch fetch() to redirect asset requests to zip blobs
     */
    function patchFetch() {
        window.fetch = async function(url, options = {}) {
            // If we have this asset in our zip, use the blob URL instead
            if (window.assetLoader && window.assetLoader.isLoaded && typeof url === 'string') {
                // Try to get the asset URL from the loader
                const blobUrl = window.assetLoader.getAssetUrl(url);
                if (blobUrl) {
                    console.log(`[C3AssetPatch] Redirecting fetch ${url} -> blob URL`);
                    return originalFetch.call(this, blobUrl, options);
                }
                
                // Also try without leading slash or with different path variations
                const variations = [
                    url.replace(/^\/+/, ''), // Remove leading slashes
                    url.replace(/^\.\//, ''), // Remove leading ./
                    url.split('/').pop(), // Just the filename
                ];
                
                for (const variation of variations) {
                    const blobUrl = window.assetLoader.getAssetUrl(variation);
                    if (blobUrl) {
                        console.log(`[C3AssetPatch] Redirecting fetch ${url} -> blob URL (via ${variation})`);
                        return originalFetch.call(this, blobUrl, options);
                    }
                }
            }
            
            // Fall back to original fetch
            return originalFetch.call(this, url, options);
        };
    }
    
    /**
     * Patch XMLHttpRequest to handle asset requests
     */
    function patchXMLHttpRequest() {
        function PatchedXMLHttpRequest() {
            const xhr = new originalXMLHttpRequest();
            const originalOpen = xhr.open;
            
            xhr.open = function(method, url, ...args) {
                // Check if this URL should be redirected to a blob
                if (window.assetLoader && window.assetLoader.isLoaded && typeof url === 'string') {
                    const blobUrl = window.assetLoader.getAssetUrl(url);
                    if (blobUrl) {
                        console.log(`[C3AssetPatch] Redirecting XHR ${url} -> blob URL`);
                        return originalOpen.call(this, method, blobUrl, ...args);
                    }
                }
                
                return originalOpen.call(this, method, url, ...args);
            };
            
            return xhr;
        }
        
        // Copy static properties
        for (const prop in originalXMLHttpRequest) {
            if (originalXMLHttpRequest.hasOwnProperty(prop)) {
                PatchedXMLHttpRequest[prop] = originalXMLHttpRequest[prop];
            }
        }
        
        window.XMLHttpRequest = PatchedXMLHttpRequest;
    }
    
    /**
     * Patch Image constructor to handle image assets
     */
    function patchImage() {
        function PatchedImage() {
            const img = new originalImage();
            const originalSrcSetter = Object.getOwnPropertyDescriptor(originalImage.prototype, 'src').set;
            
            Object.defineProperty(img, 'src', {
                get: function() {
                    return this._actualSrc || '';
                },
                set: function(url) {
                    // Check if this URL should be redirected to a blob
                    if (window.assetLoader && window.assetLoader.isLoaded && typeof url === 'string') {
                        const blobUrl = window.assetLoader.getAssetUrl(url);
                        if (blobUrl) {
                            console.log(`[C3AssetPatch] Redirecting Image src ${url} -> blob URL`);
                            this._actualSrc = url;
                            return originalSrcSetter.call(this, blobUrl);
                        }
                    }
                    
                    this._actualSrc = url;
                    return originalSrcSetter.call(this, url);
                }
            });
            
            return img;
        }
        
        // Copy static properties
        for (const prop in originalImage) {
            if (originalImage.hasOwnProperty(prop)) {
                PatchedImage[prop] = originalImage[prop];
            }
        }
        
        window.Image = PatchedImage;
    }
    
    /**
     * Patch Audio constructor to handle audio assets
     */
    function patchAudio() {
        function PatchedAudio(src) {
            const audio = new originalAudio();
            
            if (src) {
                // Check if this URL should be redirected to a blob
                if (window.assetLoader && window.assetLoader.isLoaded) {
                    const blobUrl = window.assetLoader.getAssetUrl(src);
                    if (blobUrl) {
                        console.log(`[C3AssetPatch] Redirecting Audio src ${src} -> blob URL`);
                        audio.src = blobUrl;
                        return audio;
                    }
                }
                
                audio.src = src;
            }
            
            // Patch the src property for future assignments
            const originalSrcSetter = Object.getOwnPropertyDescriptor(originalAudio.prototype, 'src').set;
            
            Object.defineProperty(audio, 'src', {
                get: function() {
                    return this._actualSrc || originalAudio.prototype.src;
                },
                set: function(url) {
                    if (window.assetLoader && window.assetLoader.isLoaded && typeof url === 'string') {
                        const blobUrl = window.assetLoader.getAssetUrl(url);
                        if (blobUrl) {
                            console.log(`[C3AssetPatch] Redirecting Audio src ${url} -> blob URL`);
                            this._actualSrc = url;
                            return originalSrcSetter.call(this, blobUrl);
                        }
                    }
                    
                    this._actualSrc = url;
                    return originalSrcSetter.call(this, url);
                }
            });
            
            return audio;
        }
        
        // Copy static properties
        for (const prop in originalAudio) {
            if (originalAudio.hasOwnProperty(prop)) {
                PatchedAudio[prop] = originalAudio[prop];
            }
        }
        
        window.Audio = PatchedAudio;
    }
    
    /**
     * Apply all patches
     */
    function applyPatches() {
        if (patchesActive) {
            console.log('[C3AssetPatch] Patches already applied');
            return;
        }
        
        console.log('[C3AssetPatch] Applying asset loading patches...');
        
        patchFetch();
        patchXMLHttpRequest();
        patchImage();
        patchAudio();
        
        patchesActive = true;
        console.log('[C3AssetPatch] All patches applied successfully');
    }
    
    /**
     * Remove all patches (restore original functions)
     */
    function removePatches() {
        if (!patchesActive) {
            return;
        }
        
        console.log('[C3AssetPatch] Removing asset loading patches...');
        
        window.fetch = originalFetch;
        window.XMLHttpRequest = originalXMLHttpRequest;
        window.Image = originalImage;
        window.Audio = originalAudio;
        
        patchesActive = false;
        console.log('[C3AssetPatch] All patches removed');
    }
    
    // Wait for asset loader to be ready, then apply patches
    window.addEventListener('assetsReady', () => {
        console.log('[C3AssetPatch] Assets ready, applying patches...');
        applyPatches();
    });
    
    // Apply patches immediately if assets are already loaded
    if (window.assetLoader && window.assetLoader.isLoaded) {
        applyPatches();
    }
    
    // Expose patch control functions globally
    window.C3AssetPatch = {
        apply: applyPatches,
        remove: removePatches,
        isActive: () => patchesActive
    };
    
})();