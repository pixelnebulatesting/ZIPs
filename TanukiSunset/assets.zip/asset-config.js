/**
 * Asset Loading Configuration
 * This file contains configuration options for the dynamic asset loading system
 */

window.AssetConfig = {
  // Main zip file containing assets
  zipFile: 'assets.zip',
  
  // Enable debug logging
  debug: true,
  
  // Timeout for zip loading (in milliseconds)
  loadTimeout: 30000,
  
  // Retry attempts for failed downloads
  maxRetries: 3,
  
  // Asset type mappings for better categorization
  assetTypes: {
    images: ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg'],
    audio: ['mp3', 'wav', 'ogg', 'aac', 'flac', 'm4a'],
    video: ['mp4', 'webm', 'ogv', 'avi', 'mov'],
    fonts: ['woff', 'woff2', 'ttf', 'otf', 'eot'],
    scripts: ['js', 'mjs'],
    data: ['json', 'xml', 'csv', 'txt'],
    unity: ['unityweb', 'data', 'wasm', 'mem']
  },
  
  // Unity-specific configuration
  unity: {
    // Enable Unity WebGL asset interception
    interceptUnityAssets: true,
    
    // Unity build folder name
    buildFolder: 'Build',
    
    // Common Unity asset patterns to intercept
    assetPatterns: [
      /\/Build\/.*\.(data|wasm|js|mem)$/,
      /\/StreamingAssets\//,
      /\.(unityweb|data)$/,
      /\.bundle$/
    ]
  },
  
  // Poki game integration (if applicable)
  poki: {
    // Enable Poki SDK integration
    enabled: false,
    
    // Poki asset loading hooks
    hooks: {
      beforeAssetLoad: null,
      afterAssetLoad: null,
      onLoadProgress: null
    }
  },
  
  // Performance settings
  performance: {
    // Enable progressive loading (load assets as needed)
    progressiveLoading: false,
    
    // Preload critical assets first
    preloadCritical: true,
    
    // Critical asset patterns (loaded first)
    criticalAssets: [
      /loading\.(png|jpg|gif)$/i,
      /logo\.(png|jpg|svg)$/i,
      /main\.(js|css)$/i,
      /game\.(data|wasm)$/i
    ],
    
    // Maximum concurrent asset extractions
    maxConcurrency: 5,
    
    // Enable memory optimization
    optimizeMemory: true
  },
  
  // Error handling
  errorHandling: {
    // Show user-friendly error messages
    showUserErrors: true,
    
    // Fallback behavior when assets fail to load
    fallbackMode: 'continue', // 'continue', 'stop', 'retry'
    
    // Custom error handler function
    onError: function(error, assetName) {
      console.error(`Asset loading error for ${assetName}:`, error);
    }
  },
  
  // UI customization
  ui: {
    // Custom loading screen HTML
    loadingScreen: null,
    
    // Progress bar customization
    progressBar: {
      color: '#4CAF50',
      backgroundColor: '#333',
      height: '20px',
      borderRadius: '10px'
    },
    
    // Loading messages
    messages: {
      initializing: 'Initializing...',
      downloading: 'Downloading assets...',
      extracting: 'Extracting assets...',
      ready: 'Game ready!',
      error: 'Failed to load assets. Please refresh the page.'
    }
  },
  
  // Advanced options
  advanced: {
    // Enable service worker for offline caching
    enableServiceWorker: false,
    
    // Custom asset processors
    processors: {
      // Example: Custom image processor
      // 'image/png': function(blob, filename) { return blob; }
    },
    
    // Asset loading hooks for custom logic
    hooks: {
      beforeZipLoad: null,
      afterZipLoad: null,
      beforeAssetExtract: null,
      afterAssetExtract: null,
      beforeGameStart: null
    }
  }
};

/**
 * Helper functions for asset configuration
 */
window.AssetConfigHelpers = {
  /**
   * Add a custom asset processor
   * @param {string} mimeType - MIME type to process
   * @param {function} processor - Processing function
   */
  addProcessor: function(mimeType, processor) {
    if (!window.AssetConfig.advanced.processors) {
      window.AssetConfig.advanced.processors = {};
    }
    window.AssetConfig.advanced.processors[mimeType] = processor;
  },
  
  /**
   * Add a hook function
   * @param {string} hookName - Name of the hook
   * @param {function} hookFunction - Function to execute
   */
  addHook: function(hookName, hookFunction) {
    if (window.AssetConfig.advanced.hooks[hookName]) {
      window.AssetConfig.advanced.hooks[hookName] = hookFunction;
    }
  },
  
  /**
   * Override default configuration
   * @param {object} config - Configuration overrides
   */
  configure: function(config) {
    window.AssetConfig = { ...window.AssetConfig, ...config };
  }
};

// Example usage:
/*
// Override zip file location
AssetConfigHelpers.configure({
  zipFile: 'custom-assets.zip'
});

// Add custom image processor
AssetConfigHelpers.addProcessor('image/png', function(blob, filename) {
  // Custom processing logic here
  return blob;
});

// Add hook for after assets are loaded
AssetConfigHelpers.addHook('afterZipLoad', function(assetLoader) {
  console.log('All assets loaded, game can start!');
});
*/
