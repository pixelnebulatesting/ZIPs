(() => {
	// Simple local PokiSDK implementation that avoids external requests
	window.PokiSDK = {
		init: function(options) {
			return new Promise(function(resolve, reject) {
				// Simulate successful initialization without external calls
				setTimeout(function() {
					resolve();
				}, 100);
			});
		},
		
		// Gameplay methods
		gameplayStart: function() {
			console.log('PokiSDK: gameplayStart (local)');
		},
		
		gameplayStop: function() {
			console.log('PokiSDK: gameplayStop (local)');
		},
		
		// Ad methods that return promises but don't actually load ads
		commercialBreak: function() {
			return new Promise(function(resolve) {
				console.log('PokiSDK: commercialBreak (local)');
				resolve();
			});
		},
		
		rewardedBreak: function() {
			return new Promise(function(resolve) {
				console.log('PokiSDK: rewardedBreak (local)');
				resolve(false); // No reward given in local mode
			});
		},
		
		// Loading methods
		gameLoadingStart: function() {
			console.log('PokiSDK: gameLoadingStart (local)');
		},
		
		gameLoadingFinished: function() {
			console.log('PokiSDK: gameLoadingFinished (local)');
		},
		
		gameLoadingProgress: function(progress) {
			console.log('PokiSDK: gameLoadingProgress (local)', progress);
		},
		
		// Other common methods
		setDebug: function(debug) {
			console.log('PokiSDK: setDebug (local)', debug);
		},
		
		captureError: function(error) {
			console.log('PokiSDK: captureError (local)', error);
		},
		
		customEvent: function(category, action, label, value) {
			console.log('PokiSDK: customEvent (local)', category, action, label, value);
		},
		
		happyTime: function(value) {
			console.log('PokiSDK: happyTime (local)', value);
		},
		
		// Utility methods
		getURLParam: function(param) {
			var urlParams = new URLSearchParams(window.location.search);
			return urlParams.get(param) || '';
		},
		
		getSharableURL: function() {
			return new Promise(function(resolve) {
				resolve(window.location.href);
			});
		},
	};
	
	console.log('PokiSDK: Local implementation loaded successfully');
})();