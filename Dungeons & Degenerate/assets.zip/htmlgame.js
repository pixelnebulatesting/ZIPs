(() => {
  // itch.io's hotlink-check-and-redirect script, neutered to a no-op.
  // PixelNebula is this game's real home, not a hotlinked embed of an
  // itch.io listing, so there is no one left to redirect away from.
})();
